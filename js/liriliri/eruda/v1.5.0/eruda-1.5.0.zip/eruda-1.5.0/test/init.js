eruda.init({
  useShadowDom: false
})
